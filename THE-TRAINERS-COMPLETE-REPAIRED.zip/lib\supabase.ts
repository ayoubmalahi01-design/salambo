import { createClient } from '@supabase/supabase-js'
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
// Accept both names: Supabase now labels the public key "publishable"; older projects call it "anon".
const key = (import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY) as string | undefined
export const isConfigured = Boolean(url && key && !url.includes('YOUR_') && !key.includes('YOUR_'))
export const supabase = createClient(url || 'https://placeholder.supabase.co', key || 'placeholder-anon-key')
